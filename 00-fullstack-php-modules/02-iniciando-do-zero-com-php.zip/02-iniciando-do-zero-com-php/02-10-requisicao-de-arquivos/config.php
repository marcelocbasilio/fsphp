<?php
define("COURSE", "FSPHP");