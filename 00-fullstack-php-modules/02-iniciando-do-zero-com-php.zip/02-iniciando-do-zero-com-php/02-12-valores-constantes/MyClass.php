<?php
/**
 * Created by PhpStorm.
 * User: robsonvleite
 * Date: 07/08/2018
 * Time: 20:06
 */

namespace Source;

class MyClass
{
    public $namespace = __NAMESPACE__;
}