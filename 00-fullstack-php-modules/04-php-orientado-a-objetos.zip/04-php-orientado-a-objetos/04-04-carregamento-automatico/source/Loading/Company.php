<?php

namespace Source\Loading;

class Company
{

}